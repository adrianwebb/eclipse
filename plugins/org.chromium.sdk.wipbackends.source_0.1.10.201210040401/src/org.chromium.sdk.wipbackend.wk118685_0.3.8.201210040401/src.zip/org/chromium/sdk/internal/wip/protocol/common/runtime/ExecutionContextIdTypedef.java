// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@116768

package org.chromium.sdk.internal.wip.protocol.common.runtime;

/**
 Id of an execution context.
 */
public class ExecutionContextIdTypedef {
  /*
   The class is 'typedef'.
   It merely holds a type javadoc and its only field refers to an actual type.
   */
  long actualType;
}

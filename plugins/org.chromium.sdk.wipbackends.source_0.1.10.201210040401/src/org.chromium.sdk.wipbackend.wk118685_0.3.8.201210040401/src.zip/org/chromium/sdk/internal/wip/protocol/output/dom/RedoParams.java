// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@108993

package org.chromium.sdk.internal.wip.protocol.output.dom;

/**
Re-does the last undone action.
 */
public class RedoParams extends org.chromium.sdk.internal.wip.protocol.output.WipParams {
  public RedoParams() {
  }

  public static final String METHOD_NAME = org.chromium.sdk.internal.wip.protocol.BasicConstants.Domain.DOM + ".redo";

  @Override protected String getRequestName() {
    return METHOD_NAME;
  }

}

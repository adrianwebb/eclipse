/* Copyright (c) 2004 Something Software Ltd. All rights reserved.*/ 
package com.something.eclipse.shelled.ui.actions;

/**
 * @author Doug - Something Software Ltd.
 * @version $Id: ActionConstants.java,v 1.1 2004/08/17 19:56:58 dougsatch Exp $
 */
public class ActionConstants
{
	public static final String SHOW_MANPAGE_ACTION = "com.something.eclipse.shelled.ui.actions.show.manpage";
}

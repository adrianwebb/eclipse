package org.chromium.sdk.internal.v8native.protocol.output;


public class ContextlessDebuggerMessage extends DebuggerMessage {
  public ContextlessDebuggerMessage(String command) {
    super(command);
  }
}

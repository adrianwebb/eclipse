// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@102140

package org.chromium.sdk.internal.wip.protocol.input.page;

@org.chromium.sdk.internal.protocolparser.JsonType
public interface AddScriptToEvaluateOnLoadData {
  /**
   Identifier of the added script.
   */
  String/*See org.chromium.sdk.internal.wip.protocol.common.page.ScriptIdentifierTypedef*/ identifier();

}

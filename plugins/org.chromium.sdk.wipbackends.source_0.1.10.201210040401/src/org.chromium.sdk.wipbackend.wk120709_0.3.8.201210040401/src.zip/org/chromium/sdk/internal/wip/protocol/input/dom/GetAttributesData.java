// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@96703

package org.chromium.sdk.internal.wip.protocol.input.dom;

/**
 Returns attributes for the specified node.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface GetAttributesData {
  /**
   An interleaved array of node attribute names and values.
   */
  java.util.List<String> attributes();

}

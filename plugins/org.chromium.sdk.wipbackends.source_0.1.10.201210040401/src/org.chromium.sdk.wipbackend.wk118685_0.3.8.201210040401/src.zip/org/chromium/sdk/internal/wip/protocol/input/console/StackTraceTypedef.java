// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@114632

package org.chromium.sdk.internal.wip.protocol.input.console;

/**
 Call frames for assertions or error messages.
 */
public class StackTraceTypedef {
  /*
   The class is 'typedef'.
   It merely holds a type javadoc and its only field refers to an actual type.
   */
  java.util.List<org.chromium.sdk.internal.wip.protocol.input.console.CallFrameValue> actualType;
}

// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@101756

package org.chromium.sdk.internal.wip.protocol.input.debugger;

/**
 Tells whether debugger supports native breakpoints.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface SupportsNativeBreakpointsData {
  /**
   True if debugger supports native breakpoints.
   */
  boolean result();

}

// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@101756

package org.chromium.sdk.internal.wip.protocol.input.debugger;

/**
 Returns location of given function.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface GetFunctionLocationData {
  /**
   Function location.
   */
  org.chromium.sdk.internal.wip.protocol.input.debugger.LocationValue location();

}

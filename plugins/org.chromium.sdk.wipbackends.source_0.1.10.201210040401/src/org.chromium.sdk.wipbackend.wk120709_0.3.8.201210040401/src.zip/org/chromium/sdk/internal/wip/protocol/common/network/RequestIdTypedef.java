// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@114632

package org.chromium.sdk.internal.wip.protocol.common.network;

/**
 Unique request identifier.
 */
public class RequestIdTypedef {
  /*
   The class is 'typedef'.
   It merely holds a type javadoc and its only field refers to an actual type.
   */
  String actualType;
}

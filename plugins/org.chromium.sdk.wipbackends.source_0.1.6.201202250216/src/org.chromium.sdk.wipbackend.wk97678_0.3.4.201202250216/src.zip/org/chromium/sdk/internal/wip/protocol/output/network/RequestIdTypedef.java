// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@96703

package org.chromium.sdk.internal.wip.protocol.output.network;

/**
 Unique request identifier.
 */
public class RequestIdTypedef {
  /*
   The class is 'typedef'.
   If merely holds a type javadoc and its only field refers to an actual type.
   */
  String actualType;
}

// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@86562

package org.chromium.sdk.internal.wip.protocol.input.page;

/**
 Searches for given string in frame / resource tree structure.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface SearchInResourcesData {
  /**
   List of search results.
   */
  java.util.List<org.chromium.sdk.internal.wip.protocol.input.page.SearchResultValue> result();

}

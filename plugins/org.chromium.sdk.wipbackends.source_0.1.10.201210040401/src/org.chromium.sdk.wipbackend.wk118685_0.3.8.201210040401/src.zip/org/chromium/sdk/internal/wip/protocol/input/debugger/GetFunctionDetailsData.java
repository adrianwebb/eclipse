// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@106352

package org.chromium.sdk.internal.wip.protocol.input.debugger;

/**
 Returns detailed informtation on given function.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface GetFunctionDetailsData {
  /**
   Information about the function.
   */
  org.chromium.sdk.internal.wip.protocol.input.debugger.FunctionDetailsValue details();

}

// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@101756

package org.chromium.sdk.internal.wip.protocol.input.debugger;

/**
 Tells whether enabling debugger causes scripts recompilation.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface CausesRecompilationData {
  /**
   True if enabling debugger causes scripts recompilation.
   */
  boolean result();

}

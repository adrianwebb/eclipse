// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@84351

package org.chromium.sdk.internal.wip.protocol.output.debugger;

/**
Steps over the statement.
 */
public class StepOverParams extends org.chromium.sdk.internal.wip.protocol.output.WipParams {
  public StepOverParams() {
  }

  public static final String METHOD_NAME = org.chromium.sdk.internal.wip.protocol.BasicConstants.Domain.DEBUGGER + ".stepOver";

  @Override protected String getRequestName() {
    return METHOD_NAME;
  }

}

// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@101756

package org.chromium.sdk.internal.wip.protocol.input.network;

/**
 Tells whether clearing browser cache is supported.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface CanClearBrowserCacheData {
  /**
   True if browser cache can be cleared.
   */
  boolean result();

}

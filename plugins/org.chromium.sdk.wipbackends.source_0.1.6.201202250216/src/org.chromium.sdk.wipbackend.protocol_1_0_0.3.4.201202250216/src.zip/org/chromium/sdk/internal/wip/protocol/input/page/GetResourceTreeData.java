// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@84775

package org.chromium.sdk.internal.wip.protocol.input.page;

/**
 Returns present frame / resource tree structure.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface GetResourceTreeData {
  /**
   Present frame / resource tree structure.
   */
  org.chromium.sdk.internal.wip.protocol.input.page.FrameResourceTreeValue frameTree();

}

// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@101756

package org.chromium.sdk.internal.wip.protocol.input.debugger;

/**
 Tells whether <code>setScriptSource</code> is supported.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface CanSetScriptSourceData {
  /**
   True if <code>setScriptSource</code> is supported.
   */
  boolean result();

}

// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: http://svn.webkit.org/repository/webkit/trunk/Source/WebCore/inspector/Inspector.json@96703

package org.chromium.sdk.internal.wip.protocol.input.runtime;

/**
 Unique object identifier.
 */
public class RemoteObjectIdTypedef {
  /*
   The class is 'typedef'.
   If merely holds a type javadoc and its only field refers to an actual type.
   */
  String actualType;
}

// Generated source.
// Generator: org.chromium.sdk.internal.wip.tools.protocolgenerator.Generator
// Origin: Local file Inspector-1.0.json.r107603.manual_fix

package org.chromium.sdk.internal.wip.protocol.input.debugger;

/**
 Returns detailed informtation on given function.
 */
@org.chromium.sdk.internal.protocolparser.JsonType
public interface GetFunctionDetailsData {
  /**
   Information about the function.
   */
  org.chromium.sdk.internal.wip.protocol.input.debugger.FunctionDetailsValue details();

}
